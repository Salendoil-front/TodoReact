import React from 'react'
import classes from './TodosItem.module.css'

const TodosItem = props => {

	return(
		<li className={classes.TodosItem}>
			<p>{props.todosItem}</p>
			<i className="fa fa-trash"  onClick={props.onDelete} />
		</li>
	)
}

export default TodosItem