import React from 'react'
import classes from './TodoBody.module.css'
import TodosItem from '../TodoBody/Todos/TodosItem'

const TodoBody = props => {

	return(
		<ul className={classes.TodoBody}> 
			{props.todos.map((todo, index) => {
				return(
					<TodosItem
					key={index}
					todosItem={todo} 
					onClick={props.onDelete} />
				)
			})}
		</ul>
	)
}

export default TodoBody