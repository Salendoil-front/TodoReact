import React from 'react'
import classes from './TodoHeader.module.css'

const TodoHeader = props => {

	return(
		<h1 className={classes.Todoheader}>Твой список дел</h1>
	)
}

export default TodoHeader