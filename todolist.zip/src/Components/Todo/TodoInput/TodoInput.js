import React from 'react'
import classes from './TodoInput.module.css'

const TodoInput = props => {

	return (
		<div className={classes.TodoInput}>
			{props.newTodos 
			? <input onChange={props.onChange} /> 
			: <button className={classes.btnBegin} onClick={props.onClick}>Начать новое дело</button>}
			{props.newTodos 
			? <button 
					className={classes.btnSend} 
					onClick={props.onPush}
					
				>Записать</button> : null}
		</div>
	)
}

export default TodoInput