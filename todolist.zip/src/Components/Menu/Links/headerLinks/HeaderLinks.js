import React from 'react'
//import classes from './headerLinks.module.css'

const HeaderLinks = props => {

	return(
		<h1>ToDoList</h1>
	)
}

export default HeaderLinks