import React from 'react'
import classes from './Todo.module.css'
import TodoHeader from '../../Components/Todo/TodoHeader/TodoHeader'
import TodoInput from '../../Components/Todo/TodoInput/TodoInput'
import TodosItem from '../../Components/Todo/TodoBody/Todos/TodosItem'
import Help from '../../Components/Help/Help'
import BurgerHelp from '../../Components/Help/BurgerHelp/BurgerHelp'
import Backdrop from '../../UI/Backdrop/Backdrop'
import TodoFooter from '../../Components/Todo/TodoFooter/TodoFooter'

class Todo extends React.Component {
	state = {
		menu: false,
		newTodos: false,
		todos: [
			'Написать первое дело',
		],
		activeTodos: ''
	}

	toggleMenuHandler = () => {
		this.setState({
			menu: !this.state.menu
		})
	}
	changeNewTodosHandler = () => {
		this.setState({
			newTodos: !this.state.newTodos
		})
	}

	changeActiveTodos = (name) => {
		this.setState({
			activeTodos: name
		})
	}



	pushNewTodos = () => {
		const todos = this.state.todos
		let activeTodos = this.state.activeTodos
		let activeTodosArr = activeTodos.split(' ')

		if(activeTodos === '' || activeTodos === ' '){
			alert('Введите дело')
		} else if(activeTodos !== ''){
			for (let i = 0; i < activeTodosArr.length; i++){
				if(activeTodosArr[i].length > 29){
					alert('Слишком большое слово')
					this.setState({
						newTodos: false
					})
				} 
			}
			todos.push(activeTodos)
			this.setState({
				todos,
				newTodos: !this.state.newTodos,
				activeTodos: null
			})
			localStorage.setItem('todosKey', this.state.todos)
		} 
	}

	deleteTodos = (index) => {
		const todos = this.state.todos.concat()
		todos.splice(index, 1)
		this.setState({
			todos
		})
		localStorage.setItem('todosKey', this.state.todos)
		console.log(localStorage.getItem('todosKey'))
	}

	clearChangesHandler = () => {
		localStorage.removeItem('todosKey', this.state.todos)
		this.setState({
			todos: [
				'Написать первое дело',
			]
		})
	}

	saveChangesHandler = () => {
		localStorage.setItem('todosKey', this.state.todos)
	}

	componentDidMount () {
		const data = localStorage.getItem('todosKey')
		if(data){
			let todos = data
			console.log(todos)
			const todosArr = todos.split(',')
			console.log(todosArr)
			this.setState({
				todos: todosArr
			})
		}
	}

	render() {
		const token = 'Bearer '+ localStorage.getItem('accesstoken')
		console.log(token)
		return (
			<div className={classes.Todo}>
				<div>
					<Help isOpen={this.state.menu} allTodos={this.state.todos.length} />
					<BurgerHelp isOpen={this.state.menu} onClick={this.toggleMenuHandler} />
					{this.state.menu ? <Backdrop onClick={this.toggleMenuHandler} /> : null}
					<div className={classes.TodoInner}>
						<TodoHeader />
						<TodoInput
							onChange={(event) => this.changeActiveTodos(event.target.value)}
							onClick={this.changeNewTodosHandler}
							newTodos={this.state.newTodos}
							onPush={this.pushNewTodos}
						/>
						<ul className={classes.TodoBody}>
							{this.state.todos.map((todo, index) => {
								return (
									<TodosItem
										key={index}
										todosItem={todo}
										onDelete={this.deleteTodos.bind(this, index)}
									/>
								)
							})}
						</ul>
						<TodoFooter
							onClick={this.saveChangesHandler}
							onClear={this.clearChangesHandler}
						/>
					</div>
				</div>
			</div>
		)
	}
}

export default Todo